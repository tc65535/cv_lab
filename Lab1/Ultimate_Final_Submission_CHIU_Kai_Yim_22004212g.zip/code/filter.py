from PIL import Image  # pillow package
import numpy as np
from scipy import ndimage


def read_img_as_array(file):
    '''read image and convert it to numpy array with dtype np.float64'''
    img = Image.open(file)
    arr = np.asarray(img, dtype=np.float64)
    return arr


def save_array_as_img(arr, file):
    min, max = arr.min(), arr.max()
    if min < 0 or max > 255:  # make sure arr falls in [0,255]
        arr = (arr - min) / (max - min) * 255

    arr = arr.astype(np.uint8)
    img = Image.fromarray(arr)
    img.save(file)


def show_array_as_img(arr, rescale='minmax'):
    # make sure arr falls in [0,255]
    min, max = arr.min(), arr.max()
    if min < 0 or max > 255:
        arr = (arr - min) / (max - min) * 255

    arr = arr.astype(np.uint8)
    img = Image.fromarray(arr)
    img.show()


def rgb2gray(arr):
    R = arr[:, :, 0]  # red channel
    G = arr[:, :, 1]  # green channel
    B = arr[:, :, 2]  # blue channel
    gray = 0.2989 * R + 0.5870 * G + 0.1140 * B
    return gray


#########################################
## Please complete following functions ##
#########################################
def sharpen(img, sigma, alpha):
    '''Sharpen the image. 'sigma' is the standard deviation of Gaussian filter. 'alpha' controls how much details to add.'''
    # TODO: Please complete this function.
    blurred = np.zeros(img.shape)
    for i in range(0, 3):  # for each RGB
        blurred[:, :, i] = ndimage.gaussian_filter(img[:, :, i], sigma=sigma)

    detailed = img - blurred
    sharpened = img + detailed * alpha

    sharpened[sharpened < 0] = 0
    sharpened[sharpened > 255] = 255

    return sharpened


def median_filter(img, s):
    '''Perform median filter of size s x s to image 'arr', and return the filtered image.'''
    # TODO: Please complete this function.
    h, w, c = img.shape  # get image h & w & channel

    m_idx = (s ** 2) // 2  # pre-calculate the index of median of a 1d array
    m = s // 2  # pre-calculate the length of margin

    new_img = np.copy(img)  # create a new image from original image
    # new_img = np.zeros((h, w, c))  # or create a new image fill with zeros

    for i in range(c):  # for each RGB channel
        for j in range(m, h - m):  # for each row
            for k in range(m, w - m):  # for each column
                # 3x3 / 5x5 / 7x7 / 9x9 ... filter
                f = img[:, :, i][(j - m):(j + m + 1), (k - m):(k + m + 1)]
                median = np.sort(f.ravel())[m_idx]  # make 1d arr, sort, and get median
                new_img[:, :, i][j, k] = median  # replace pixel value to median value
    return new_img


if __name__ == '__main__':
    input_path = '../data/rain.jpeg'
    img = read_img_as_array(input_path)
    # show_array_as_img(img)
    # TODO: finish assignment Part I.

    sharpened = sharpen(img, 3, 2)
    save_array_as_img(sharpened, '../data/1.1_sharpened.jpg')

    # by testing 3x3, 5x5, 7x7, 9x9 filter, 5x5 filter has the best effect on eliminating rain drop
    derained = median_filter(img, 5)
    save_array_as_img(derained, '../data/1.2_derained.jpg')
