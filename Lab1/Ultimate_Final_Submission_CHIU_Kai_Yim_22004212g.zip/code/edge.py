import json
import math

import numpy as np
from PIL import Image, ImageDraw  # pillow package
from scipy import ndimage


def read_img_as_array(file):
    '''read image and convert it to numpy array with dtype np.float64'''
    img = Image.open(file)
    arr = np.asarray(img, dtype=np.float64)
    return arr


def save_array_as_img(arr, file):
    # make sure arr falls in [0,255]
    min, max = arr.min(), arr.max()
    if min < 0 or max > 255:
        arr = (arr - min) / (max - min) * 255

    arr = arr.astype(np.uint8)
    img = Image.fromarray(arr)
    img.save(file)


def show_array_as_img(arr):
    min, max = arr.min(), arr.max()
    if min < 0 or max > 255:  # make sure arr falls in [0,255]
        arr = (arr - min) / (max - min) * 255

    arr = arr.astype(np.uint8)
    img = Image.fromarray(arr)
    img.show()


def rgb2gray(arr):
    R = arr[:, :, 0]  # red channel
    G = arr[:, :, 1]  # green channel
    B = arr[:, :, 2]  # blue channel
    gray = 0.2989 * R + 0.5870 * G + 0.1140 * B
    return gray


#########################################
## Please complete following functions ##
#########################################
def gaussian_smoothing(img, sigma):
    blurred = ndimage.gaussian_filter(img, sigma=sigma)
    return blurred


def sobel(arr):
    '''Apply sobel operator on arr and return the result.'''
    # TODO: Please complete this function.
    # your code here
    kernel_x = [[1, 0, -1],
                [2, 0, -2],
                [1, 0, -1]]
    Gx = ndimage.convolve(arr, kernel_x)

    kernel_y = [[1, 2, 1],
                [0, 0, 0],
                [-1, -2, -1]]
    Gy = ndimage.convolve(arr, kernel_y)

    G = np.sqrt(np.square(Gx) + np.square(Gy))

    return G, Gx, Gy


def nonmax_suppress(G, Gx, Gy):
    '''Suppress non-max value along direction perpendicular to the edge.'''
    assert G.shape == Gx.shape
    assert G.shape == Gy.shape
    # TODO: Please complete this function.
    # your code here
    suppressed_G = G.copy()  # make a copy of G, G is for reference, suppressed_G is for changes
    theta = np.arctan2(Gy, Gx) * 180 / np.pi

    r, c = theta.shape

    for i in range(1, r - 1):  # up, down, left, right have 1 pixel of margin
        for j in range(1, c - 1):
            n1 = None
            n2 = None
            angle = theta[i, j]

            if -22.5 <= angle <= 22.5 or 157.5 <= angle <= 180 or -157.5 <= angle <= -180:
                n1 = G[i, j + 1]
                n2 = G[i, j - 1]
            elif 22.5 <= angle <= 67.5 or -112.5 <= angle <= -157.5:
                n1 = G[i + 1, j + 1]
                n2 = G[i - 1, j - 1]
            elif 67.5 <= angle <= 112.5 or -67.5 <= angle <= -112.5:
                n1 = G[i + 1, j]
                n2 = G[i - 1, j]
            elif 112.5 <= angle <= 157.5 or -22.5 <= angle <= -67.5:
                n1 = G[i - 1, j + 1]
                n2 = G[i + 1, j - 1]

            if G[i, j] < n1 or G[i, j] < n2:
                suppressed_G[i, j] = 0

    return suppressed_G


def thresholding(G, t):
    '''Binarize G according threshold t'''
    G_binary = G.copy()
    G_binary[G_binary < t] = 0
    return G_binary


def hysteresis_thresholding(G, low, high):
    '''Binarize G according threshold low and high'''
    # TODO: Please complete this function.
    # your code here
    G_low = thresholding(G, low)
    G_high = thresholding(G, high)
    G_hyst = np.copy(G_high)

    # use breadth-first search to make G_hyst from G_high and G_low
    visited = []

    h, w = G_hyst.shape
    r_idx_set, c_idx_set = np.nonzero(G_high)  # cache all row, column indexes of nonzero element of G_high
    num_idx_set = len(c_idx_set)
    for i in range(num_idx_set):
        r = r_idx_set[i]
        c = c_idx_set[i]

        queue = [(r, c)]  # start to find neighbour from the front
        while len(queue) > 0:
            current = queue.pop(0)  # get current coordinate (x,y)
            # find potential neighbour in eight direction (optimistic), or in four direction (pessimistic)
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (-1, 1), (1, -1), (-1, -1)):
                new_r = current[0] + dx
                new_c = current[1] + dy
                coor = (new_r, new_c)
                if (0 <= new_r < h and 0 <= new_c < w) and (coor not in queue) and (coor not in visited) and (
                        G_low[new_r, new_c] > 0):
                    # if a valid neighbour has been found in G_low, it is stick to strong edge pixels, which is what we want.
                    G_hyst[new_r, new_c] = G_low[new_r, new_c]  # assign that weak edge pixels to G_hyst directly
                    # put the neighbour to the back of the queue list
                    # and use it to kidnap other neighbour later until all neighbours got found
                    queue.append(coor)
                    visited.append(coor)

    return G_low, G_high, G_hyst


def hough(G_hyst):
    '''Return Hough transform of G'''
    # TODO: Please complete this function.
    # your code here

    h, w = G_hyst.shape
    d = int(np.sqrt(h ** 2 + w ** 2))

    thetas = np.linspace(0, np.pi, 1000)  # discretize theta to 1000 parts
    num_thetas = len(thetas)

    rhos = np.linspace(-d, d, d * 2)  # discretize rho to double of its diagonal
    num_rhos = len(rhos)

    accumulator = np.zeros((num_rhos, num_thetas))  # create a 2D array representing the Hough Space

    r_idx_set, c_idx_set = np.nonzero(G_hyst)  # coordinate of edge pixels
    num_idx_set = len(r_idx_set)

    cos_set = np.cos(thetas)  # pre-calculate all cos
    sin_set = np.sin(thetas)  # pre-calculate all sin

    # backward_tracing = []  # for reference only, these comments are for backward tracing of coordinates only, not for hough transform
    for i in range(num_idx_set):
        for j in range(num_thetas):
            rho = int(r_idx_set[i] * cos_set[j] + c_idx_set[i] * sin_set[j] + d)
            accumulator[rho, j] += 1
            # backward_tracing.append((rho, j, i))  # for backward tracing of coordinates only, not for hough transform
    # with open("backward_tracing.json", 'w') as file_object:
    #     json.dump(backward_tracing, file_object)  # store backward tracing data in a json file (very large, about 340mb)
    # ***backward tracing method is for drawing straight lines (Method 1), running this function may require a very long runtime

    return accumulator


def inspect_accumulator():  # a simple function use to observe the coordinates of interception in accumulator
    import matplotlib.image as mpimg
    import matplotlib.pyplot as plt
    accumulator = mpimg.imread('../data/2.6_hough.jpg')
    plt.imshow(accumulator)
    plt.show()


def draw_lines_on_original_image1():
    # Method 1
    # 1. tracing the indexes of coordinate in edgemap according to the observation in hough
    f = open('backward_tracing.json')
    backward_tracing_data = json.load(f)

    observed = [[1532, 119], [1561, 147], [1564, 148], [1624, 499], [1615, 511]]

    edge_indexes = []
    # the goal is to find out all pixels (or lines) that pass through the intercept,
    # these pixels will form different straight lines theoretically
    for interception in observed:  # it takes a very long time to trace
        indexes = [x[2] for x in backward_tracing_data if x[0] == interception[0] and x[1] == interception[1]]
        edge_indexes.append(indexes)  # these indexes represent the coordinates of edge in edgemap
    f.close()

    # print(edge_indexes)

    # 2. read the edge_indexes to get the coordinates of the edge point
    gray_image = read_img_as_array('../data/2.5_edgemap.jpg')  # need the help of edgemap
    r_idx_set, c_idx_set = np.nonzero(gray_image)
    edge_pixels = []
    for indexes in edge_indexes:
        tmp = []
        for el in indexes:
            r = r_idx_set[el]
            c = c_idx_set[el]
            tmp.append((r, c))  # this (r, c) set lies on the same line theoretically
        edge_pixels.append(tmp)  # all edges are collected, and they are ready to be used to plot a line

    # print(edge_pixels)

    # 3. plot the lines on original img according to edge_pixels
    original_image = '../data/road.jpeg'
    img = Image.open(original_image)
    draw = ImageDraw.Draw(img)
    for edge in edge_pixels:
        for i in range(len(edge) - 1):
            f_r, f_c = edge[i]
            t_r, t_c = edge[i + 1]
            draw.line((f_c, f_r, t_c, t_r), fill=255)  # plot the line in red

    # 4. save the image
    img.save("../data/method_1.jpg", quality=100, subsampling=0)
    img.save("../data/2.7_detection_result.jpg", quality=100, subsampling=0)


def draw_lines_on_original_image2():
    # Method 2
    final_img = Image.open('../data/road.jpeg')
    draw = ImageDraw.Draw(final_img)

    original_reference = read_img_as_array('../data/road.jpeg')
    accumulator = read_img_as_array('../data/2.6_hough.jpg')
    h, w, c = original_reference.shape

    d = int(math.sqrt(h ** 2 + w ** 2))
    thetas = np.linspace(0, np.pi, 1000)

    # Select the first 20 largest (rho, theta) pairs
    largest = np.unique(np.sort(np.array(accumulator).ravel()))[-20:][::-1]

    for value in largest:
        pairs = np.argwhere(accumulator == value)
        for pair in pairs:
            rho = pair[0]
            theta = thetas[pair[1]]

            points = []
            for x in range(0, w):
                y = int((rho - d - x * np.cos(theta)) / np.sin(theta))
                points.append((x, y))

            for i in range(0, len(points) - 1):
                f_r, f_c = points[i + 1]
                t_r, t_c = points[i]
                draw.line((f_c, f_r, t_c, t_r), fill=255)  # plot the line in red
    final_img.save("../data/method2.jpg", quality=100, subsampling=0)
    final_img.save("../data/2.7_detection_result.jpg", quality=100, subsampling=0)


def draw_lines_on_original_image3():
    # Method 3
    final_img = Image.open('../data/road.jpeg')
    draw = ImageDraw.Draw(final_img)

    original_reference = read_img_as_array('../data/road.jpeg')
    h, w, c = original_reference.shape

    d = int(math.sqrt(h ** 2 + w ** 2))
    thetas = np.linspace(0, np.pi, 1000)

    # manually inspect the accumulator to find out the most possible straight line,
    # details could be referred to discussion.pdf

    # add more roh-theta pairs to show more straight lines
    pairs = [[1532, 119], [1561, 147], [1564, 148], [1624, 499], [1615, 511], [1611, 515], [1192, 827]]

    for pair in pairs:
        rho = pair[0]
        theta = thetas[pair[1]]

        points = []
        for x in range(0, w):
            # derive the y by trying different value of rho, theta, and x
            y = int((rho - d - x * np.cos(theta)) / np.sin(theta))
            points.append((x, y))

        for i in range(0, len(points) - 1):
            f_r, f_c = points[i + 1]
            t_r, t_c = points[i]
            draw.line((f_c, f_r, t_c, t_r), fill=255)  # plot the line in red
    final_img.save("../data/2.7_detection_result.jpg", quality=100, subsampling=0)


if __name__ == '__main__':
    input_path = '../data/road.jpeg'
    img = read_img_as_array(input_path)
    # show_array_as_img(img)
    # TODO: finish assignment Part II: detect edges on 'img'

    gray = rgb2gray(img)
    save_array_as_img(gray, '../data/2.1_gray.jpg')

    img = read_img_as_array('../data/2.1_gray.jpg')
    smoothing = gaussian_smoothing(img, 1)
    save_array_as_img(smoothing, '../data/2.2_gauss.jpg')

    img = read_img_as_array('../data/2.2_gauss.jpg')
    G, Gx, Gy = sobel(img)
    save_array_as_img(G, '../data/2.3_G.jpg')
    save_array_as_img(Gx, '../data/2.3_G_x.jpg')
    save_array_as_img(Gy, '../data/2.3_G_y.jpg')

    G = read_img_as_array('../data/2.3_G.jpg')
    Gx = read_img_as_array('../data/2.3_G_x.jpg')
    Gy = read_img_as_array('../data/2.3_G_y.jpg')
    suppressed_G = nonmax_suppress(G, Gx, Gy)
    save_array_as_img(suppressed_G, '../data/2.4_supress.jpg')

    suppressed_G = read_img_as_array('../data/2.4_supress.jpg')
    G_low, G_high, G_hyst = hysteresis_thresholding(suppressed_G, 15, 180)
    save_array_as_img(G_low, '../data/2.5_edgemap_low.jpg')
    save_array_as_img(G_high, '../data/2.5_edgemap_high.jpg')
    save_array_as_img(G_hyst, '../data/2.5_edgemap.jpg')

    G_hyst = read_img_as_array('../data/2.5_edgemap.jpg')
    accumulator = hough(G_hyst)
    save_array_as_img(accumulator, '../data/2.6_hough.jpg')

    # inspect_accumulator()  # for reference only, please comment this code if not in used, otherwise the program will get stuck here

    # draw_lines_on_original_image1() # Method 1, for reference only
    # draw_lines_on_original_image2() # Method 2, for reference only
    draw_lines_on_original_image3()  # Method 3

